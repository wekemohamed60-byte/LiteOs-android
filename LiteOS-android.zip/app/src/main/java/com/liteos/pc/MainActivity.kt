package com.liteos.pc

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    class App(val name: String, val icon: String, val url: String)
    class Win(val app: App, val frame: LinearLayout, val btn: TextView, val web: WebView?)

    private lateinit var top: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var grid: GridLayout
    private lateinit var tasks: LinearLayout
    private lateinit var menuList: LinearLayout
    private lateinit var menu: ScrollView
    private lateinit var clock: TextView
    private val wins = mutableListOf<Win>()
    private var cur: Win? = null
    private var fsView: View? = null
    private var fsCb: WebChromeClient.CustomViewCallback? = null
    private var note: EditText? = null
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("liteos", MODE_PRIVATE) }

    private val base = listOf(
        App("Navigateur", "🌐", "https://www.google.com"),
        App("ChatGPT", "🤖", "https://chatgpt.com"),
        App("Gemini", "✨", "https://gemini.google.com"),
        App("YouTube", "▶️", "https://m.youtube.com"),
        App("Bloc-notes", "📝", "app:notes"),
        App("Store", "🛍️", "app:store")
    )
    private val suggestions = listOf(
        App("Claude", "🔗", "https://claude.ai"),
        App("WhatsApp", "🔗", "https://web.whatsapp.com"),
        App("Facebook", "🔗", "https://m.facebook.com"),
        App("TikTok", "🔗", "https://www.tiktok.com"),
        App("Netflix", "🔗", "https://www.netflix.com"),
        App("Spotify", "🔗", "https://open.spotify.com")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun custom(): List<App> = prefs.getString("apps", "")!!.lines().filter { it.contains("|") }
        .map { val p = it.split("|", limit = 2); App(p[0], "🔗", p[1]) }
    private fun saveCustom(l: List<App>) =
        prefs.edit().putString("apps", l.joinToString("\n") { it.name + "|" + it.url }).apply()
    private fun all() = base + custom()

    private fun tv(t: String, sp: Float = 16f, c: Int = Color.WHITE, f: (() -> Unit)? = null) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER
        f?.let { fn -> setOnClickListener { fn() } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        top = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0F2B5B.toInt(), 0xFF1D6FD1.toInt(), 0xFF6FC3FF.toInt())
            )
        }
        grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(12), dp(8), 0) }
        content.addView(grid, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        menuList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        menu = ScrollView(this).apply {
            visibility = View.GONE; setBackgroundColor(0xF2202020.toInt()); addView(menuList)
        }
        content.addView(menu, FrameLayout.LayoutParams(dp(280), dp(360), Gravity.BOTTOM or Gravity.START))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF202020.toInt())
        }
        bar.addView(tv("⊞", 26f, 0xFF4CC2FF.toInt()) { toggleMenu() }, LinearLayout.LayoutParams(dp(52), MATCH_PARENT))
        tasks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(tasks, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        clock = tv("", 13f)
        bar.addView(clock, LinearLayout.LayoutParams(dp(56), MATCH_PARENT))

        col.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        col.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)))
        top.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(top)
        rebuild(); tick()
    }

    private fun tick() {
        clock.text = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date())
        h.postDelayed({ tick() }, 15000)
    }

    private fun toggleMenu() {
        if (menu.visibility == View.VISIBLE) menu.visibility = View.GONE
        else { menu.bringToFront(); menu.visibility = View.VISIBLE }
    }

    private fun rebuild() {
        grid.removeAllViews(); menuList.removeAllViews()
        all().forEach { a ->
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            c.addView(tv(a.icon, 32f)); c.addView(tv(a.name, 12f))
            c.setOnClickListener { open(a) }
            grid.addView(c, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels / 4 - dp(4) })
            val r = tv(a.icon + "  " + a.name, 16f) { menu.visibility = View.GONE; open(a) }
            r.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            r.setPadding(dp(12), dp(12), dp(12), dp(12))
            menuList.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val q = tv("⏻  Quitter", 16f, 0xFFFF8A80.toInt()) { finish() }
        q.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        q.setPadding(dp(12), dp(12), dp(12), dp(12))
        menuList.addView(q, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
    }

    private fun open(a: App) {
        if (a.url.startsWith("app:")) {
            val ex = wins.firstOrNull { it.app.url == a.url }
            if (ex != null) { show(ex); return }
        }
        if (wins.size >= 5) {
            Toast.makeText(this, "5 fenêtres maximum : ferme-en une", Toast.LENGTH_SHORT).show(); return
        }
        var wv: WebView? = null
        val body: View = when (a.url) {
            "app:notes" -> notes()
            "app:store" -> store()
            else -> { val p = web(a); wv = p.second; p.first }
        }
        val frame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val tb = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFFF0F0F0.toInt())
        }
        val title = tv(a.icon + " " + a.name, 14f, Color.BLACK)
        title.gravity = Gravity.START or Gravity.CENTER_VERTICAL; title.setPadding(dp(12), 0, 0, 0)
        tb.addView(title, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        val btn = tv(a.icon, 20f)
        lateinit var w: Win
        tb.addView(tv("–", 20f, Color.BLACK) { minimize(w) }, LinearLayout.LayoutParams(dp(52), MATCH_PARENT))
        tb.addView(tv("✕", 18f, Color.BLACK) { close(w) }, LinearLayout.LayoutParams(dp(52), MATCH_PARENT))
        frame.addView(tb, LinearLayout.LayoutParams(MATCH_PARENT, dp(38)))
        frame.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        w = Win(a, frame, btn, wv)
        btn.setOnClickListener { if (cur === w) minimize(w) else show(w) }
        tasks.addView(btn, LinearLayout.LayoutParams(dp(48), MATCH_PARENT))
        content.addView(frame, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        wins.add(w); show(w)
    }

    private fun show(w: Win) {
        menu.visibility = View.GONE
        wins.forEach { it.frame.visibility = if (it === w) View.VISIBLE else View.GONE }
        cur = w; mark()
    }

    private fun minimize(w: Win) {
        w.frame.visibility = View.GONE
        if (cur === w) cur = null
        mark()
    }

    private fun close(w: Win) {
        if (w.app.url == "app:notes") saveNote()
        content.removeView(w.frame); tasks.removeView(w.btn); w.web?.destroy(); wins.remove(w)
        if (cur === w) cur = null
        mark()
    }

    private fun mark() {
        wins.forEach { it.btn.setBackgroundColor(if (it === cur) 0xFF444444.toInt() else Color.TRANSPARENT) }
    }

    private fun saveNote() { note?.let { prefs.edit().putString("note", it.text.toString()).apply() } }

    private fun notes(): View = EditText(this).apply {
        setText(prefs.getString("note", "")); hint = "Écris ici…"
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        gravity = Gravity.TOP or Gravity.START
        setBackgroundColor(Color.WHITE); setTextColor(Color.BLACK)
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }.also { note = it }

    private fun store(): View {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        fillStore(ll)
        return ScrollView(this).apply { setBackgroundColor(Color.WHITE); addView(ll) }
    }

    private fun fillStore(ll: LinearLayout) {
        ll.removeAllViews()
        ll.addView(tv("Installer une app web", 18f, Color.BLACK))
        val name = EditText(this).apply { hint = "Nom"; setTextColor(Color.BLACK) }
        val url = EditText(this).apply {
            hint = "Adresse (ex : chatgpt.com)"; setTextColor(Color.BLACK)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        ll.addView(name); ll.addView(url)
        val ok = tv("Installer", 16f) { install(name.text.toString(), url.text.toString(), ll) }
        ok.setBackgroundColor(0xFF0078D4.toInt()); ok.setPadding(dp(12), dp(12), dp(12), dp(12))
        ll.addView(ok)
        ll.addView(tv("Suggestions", 16f, Color.BLACK).apply { setPadding(0, dp(16), 0, dp(4)) })
        suggestions.forEach { s ->
            val r = tv("＋ " + s.name, 15f, 0xFF0078D4.toInt()) { install(s.name, s.url, ll) }
            r.gravity = Gravity.START; r.setPadding(dp(4), dp(10), dp(4), dp(10)); ll.addView(r)
        }
        val c = custom()
        if (c.isNotEmpty()) {
            ll.addView(tv("Installées", 16f, Color.BLACK).apply { setPadding(0, dp(16), 0, dp(4)) })
            c.forEach { a ->
                val r = tv("🗑 " + a.name, 15f, 0xFFD13438.toInt()) {
                    saveCustom(custom().filter { it.name != a.name }); rebuild(); fillStore(ll)
                }
                r.gravity = Gravity.START; r.setPadding(dp(4), dp(10), dp(4), dp(10)); ll.addView(r)
            }
        }
    }

    private fun install(n: String, u: String, ll: LinearLayout) {
        val name = n.trim().replace("|", " ").replace("\n", " ")
        var url = u.trim()
        if (name.isEmpty() || url.isEmpty()) return
        if (!url.startsWith("http")) url = "https://$url"
        saveCustom(custom().filter { it.name != name } + App(name, "🔗", url))
        rebuild(); fillStore(ll)
        Toast.makeText(this, "$name installée", Toast.LENGTH_SHORT).show()
    }

    private fun go(wv: WebView, t: String) {
        val q = t.trim()
        wv.loadUrl(
            when {
                q.startsWith("http") -> q
                q.contains(".") && !q.contains(" ") -> "https://$q"
                else -> "https://www.google.com/search?q=" + Uri.encode(q)
            }
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun web(a: App): Pair<View, WebView> {
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = true; displayZoomControls = false
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/[\\d.]+ "), "")
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(wv, true) }
        val et = EditText(this).apply {
            setSingleLine(); setTextColor(Color.BLACK); textSize = 13f
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(0xFFEEEEEE.toInt()); setPadding(dp(8), 0, dp(8), 0)
        }
        et.setOnEditorActionListener { _, _, _ -> go(wv, et.text.toString()); true }
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) { if (!et.hasFocus()) et.setText(u) }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
                v.setBackgroundColor(Color.BLACK); fsView = v; fsCb = cb
                top.addView(v, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            }
            override fun onHideCustomView() {
                fsView?.let { top.removeView(it) }; fsView = null; fsCb = null
            }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFFEEEEEE.toInt())
        }
        bar.addView(tv("◀", 18f, Color.BLACK) { if (wv.canGoBack()) wv.goBack() }, LinearLayout.LayoutParams(dp(44), dp(40)))
        bar.addView(tv("▶", 18f, Color.BLACK) { if (wv.canGoForward()) wv.goForward() }, LinearLayout.LayoutParams(dp(44), dp(40)))
        bar.addView(tv("⟳", 18f, Color.BLACK) { wv.reload() }, LinearLayout.LayoutParams(dp(44), dp(40)))
        bar.addView(et, LinearLayout.LayoutParams(0, dp(40), 1f))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        col.addView(wv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        wv.loadUrl(a.url)
        return Pair(col, wv)
    }

    override fun onPause() { saveNote(); super.onPause() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val v = fsView
        if (v != null) { fsCb?.onCustomViewHidden(); top.removeView(v); fsView = null; return }
        if (menu.visibility == View.VISIBLE) { menu.visibility = View.GONE; return }
        val w = cur
        if (w == null) { super.onBackPressed(); return }
        val wv = w.web
        if (wv != null && wv.canGoBack()) wv.goBack() else minimize(w)
    }
}
